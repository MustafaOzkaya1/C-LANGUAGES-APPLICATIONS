﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proje4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        string siraKimde = "X";
        int skor1, skor2, hamleSayisi;
        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = Form1.oyuncu1;
            label2.Text = Form1.oyuncu2;
            label3.Text = "0";
            label4.Text = "0";

        }

        private void button10_Click(object sender, EventArgs e)
        {
            temizle();
            butonAc();
            button10.Enabled = false;
        }

        public void temizle()
        {
            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
        }

        public void butonAc()
        {
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
        }

        public void butonKapat()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            (sender as Button).Text = siraKimde;

            hamleSayisi++;
            (sender as Button).Enabled = false;
            kontrol();

            if (siraKimde == "X")
            {
                siraKimde = "O";
            }
            else
            {
                siraKimde = "X";
            }
        }

        public void kontrol()
        {
            if (
               (button1.Text == button2.Text && button1.Text == button3.Text && button1.Text != "") ||
               (button4.Text == button5.Text && button4.Text == button6.Text && button4.Text != "") ||
               (button7.Text == button8.Text && button7.Text == button9.Text && button7.Text != "") ||
               (button1.Text == button4.Text && button1.Text == button7.Text && button1.Text != "") ||
               (button2.Text == button5.Text && button2.Text == button8.Text && button2.Text != "") ||
               (button3.Text == button6.Text && button3.Text == button9.Text && button3.Text != "") ||
               (button1.Text == button5.Text && button1.Text == button9.Text && button1.Text != "") ||
               (button3.Text == button5.Text && button3.Text == button7.Text && button3.Text != "")
               )
            {
                if (siraKimde == "X")
                {
                    skor1++;
                    label3.Text = skor1.ToString();
                }
                else
                {
                    skor2++;
                    label4.Text = skor2.ToString();
                }
                button10.Text = "TEKRAR";
                button10.Enabled = true;
                butonKapat();

            }
            else
            {
                if (hamleSayisi==9)
                {
                    MessageBox.Show("BERABERLİK", "UYARI",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    button10.Text = "TEKRAR";
                    button10.Enabled = true;
                }
            }
        }
    }
}
